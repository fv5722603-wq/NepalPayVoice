# NepalPay Voice Android Starter

This is a **demo Android Studio project**, not a production payment application.

## Open and build
1. Install Android Studio (recent stable version) and a compatible JDK.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync to finish. Android Studio may install required SDK components.
4. Connect an Android phone with USB debugging enabled or start an emulator.
5. Select the `app` run configuration and press Run.
6. To create a debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## What works
- Merchant dashboard with sample totals
- Adds random **demo-only** transactions
- Android Text-to-Speech voice test
- Nepali/English toggle and volume slider
- Demo device status and transaction history

## Not implemented
- No bank/Fonepay/NEPALPAY QR API integration
- No real payment verification or settlement
- No 4G speaker hardware connection
- No production login, merchant onboarding, cloud backend or device security

Do not use the demo transaction button to claim that real money was received. For a production version, integrate only with an authorized payment partner under a signed agreement; verify signed webhook/API events server-side and implement idempotency, device authentication, audit logging, and security testing.
