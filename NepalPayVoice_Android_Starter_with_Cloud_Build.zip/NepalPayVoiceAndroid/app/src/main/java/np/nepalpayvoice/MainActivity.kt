package np.nepalpayvoice

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import java.text.NumberFormat
import java.util.Locale

data class DemoTx(val id: String, val amount: Int, val time: String)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val navy = Color.rgb(16, 43, 70)
    private val blue = Color.rgb(23, 105, 170)
    private val teal = Color.rgb(22, 160, 133)
    private val pale = Color.rgb(243, 247, 251)
    private var tts: TextToSpeech? = null
    private var total = 2450
    private var count = 8
    private var seq = 2402
    private val tx = mutableListOf(
        DemoTx("DEMO-2401", 500, "20:42"),
        DemoTx("DEMO-2400", 250, "20:35"),
        DemoTx("DEMO-2399", 1000, "20:18"),
        DemoTx("DEMO-2398", 200, "19:56"),
        DemoTx("DEMO-2397", 500, "19:31")
    )
    private lateinit var totalView: TextView
    private lateinit var countView: TextView
    private lateinit var listView: LinearLayout
    private lateinit var displayView: TextView
    private var nepaliVoice = true
    private var volume = 0.75f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ne", "NP")
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, color: Int = navy, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(Color.WHITE)
        elevation = dp(2).toFloat()
    }
    private fun button(text: String, color: Int = blue, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text; setTextColor(Color.WHITE); setBackgroundColor(color)
            setOnClickListener { action() }
        }
    private fun addSpace(parent: LinearLayout, height: Int = 10) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(pale) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }
        scroll.addView(page)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(navy)
        }
        header.addView(label("♫  NepalPay Voice", 24f, Color.WHITE, true))
        header.addView(label("Merchant Soundbox · Demo Prototype", 13f, Color.rgb(207,225,240)))
        addSpace(header, 10)
        header.addView(label("● DEMO MODE — Real payments not connected", 12f, Color.rgb(255,220,150)))
        page.addView(header)
        addSpace(page, 16)

        val dash = card()
        dash.addView(label("Merchant Dashboard", 20f, navy, true))
        dash.addView(label("Namaste Mart · Merchant ID: NPVD-0001", 13f, Color.GRAY))
        addSpace(dash, 14)
        totalView = label("आजको कारोबार\nरु. 2,450", 22f, teal, true)
        dash.addView(totalView)
        addSpace(dash, 6)
        countView = label("भुक्तानी संख्या: 8", 16f, navy, true)
        dash.addView(countView)
        addSpace(dash, 8)
        dash.addView(button("＋ Demo Payment थप्नुहोस्", teal) { addDemoPayment() })
        dash.addView(button("🔊 आवाज परीक्षण") { speak(if (nepaliVoice) "नेपालपे भ्वाइस, आवाज परीक्षण सफल।" else "NepalPay Voice, sound test successful.") })
        dash.addView(button("भाषा परिवर्तन: नेपाली / English", navy) {
            nepaliVoice = !nepaliVoice
            Toast.makeText(this, if (nepaliVoice) "नेपाली आवाज चयन गरियो" else "English voice selected", Toast.LENGTH_SHORT).show()
            tts?.language = if (nepaliVoice) Locale("ne", "NP") else Locale.US
        })
        val seek = SeekBar(this).apply {
            max = 100; progress = 75
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) { volume = progress / 100f }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dash.addView(label("Speaker volume", 13f, Color.GRAY))
        dash.addView(seek)
        page.addView(dash)
        addSpace(page, 16)

        val device = card()
        device.addView(label("4G Soundbox", 20f, navy, true))
        addSpace(device, 8)
        displayView = label("READY", 28f, teal, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(18)); setBackgroundColor(navy)
        }
        device.addView(displayView)
        addSpace(device, 8)
        device.addView(label("Network: Connected (Demo) · Battery: 92%", 13f, teal))
        device.addView(label("Device ID: NPV-TEST-0001", 13f, Color.GRAY))
        page.addView(device)
        addSpace(page, 16)

        val history = card()
        history.addView(label("हालैका कारोबार", 20f, navy, true))
        history.addView(label("नमुना कारोबार मात्र", 12f, Color.GRAY))
        addSpace(history, 8)
        listView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        history.addView(listView)
        page.addView(history)
        addSpace(page, 16)
        page.addView(label("महत्त्वपूर्ण: यो demo ले कृत्रिम कारोबार मात्र देखाउँछ। बैंक API, वास्तविक QR भुक्तानी वा Speaker hardware सँग जोडिएको छैन। उत्पादनमा जानुअघि अधिकृत Payment Partner को API र सुरक्षा परीक्षण आवश्यक छ।", 12f, Color.DKGRAY))
        setContentView(scroll)
        renderTransactions()
    }

    private fun addDemoPayment() {
        val amount = listOf(100, 200, 250, 500, 1000).random()
        val time = java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())
        tx.add(0, DemoTx("DEMO-$seq", amount, time))
        seq++; total += amount; count++
        displayView.text = NumberFormat.getIntegerInstance(Locale("en", "IN")).format(amount)
        totalView.text = "आजको कारोबार\nरु. " + NumberFormat.getIntegerInstance(Locale("en", "IN")).format(total)
        countView.text = "भुक्तानी संख्या: $count"
        renderTransactions()
        Toast.makeText(this, "Demo transaction — वास्तविक भुक्तानी होइन", Toast.LENGTH_LONG).show()
        speak(if (nepaliVoice) "डेमो भुक्तानी। $amount रुपैयाँ प्राप्त भयो।" else "Demo payment. $amount rupees received.")
    }

    private fun renderTransactions() {
        if (!::listView.isInitialized) return
        listView.removeAllViews()
        tx.take(8).forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(10))
            }
            row.addView(label("${item.time}  ·  ${item.id}", 12f, Color.GRAY))
            row.addView(label("रु. ${item.amount}   •   DEMO", 16f, navy, true))
            listView.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.LTGRAY) }
            listView.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun speak(message: String) {
        tts?.setSpeechRate(0.9f)
        tts?.setPitch(1.0f)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "npv-demo-${System.currentTimeMillis()}")
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}
