# Build the APK using only your phone

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

1. Sign in to GitHub in your phone browser and create a new repository named `NepalPayVoice`.
2. Extract this ZIP on your phone.
3. Upload the *contents* of the extracted `NepalPayVoiceAndroid` folder to the repository root. Make sure `.github/workflows/android-apk.yml` is included. If your phone's file picker hides dot-folders, use GitHub's web upload or a ZIP-aware GitHub client that can upload the folder contents.
4. Open the repository's **Actions** tab and select **Build NepalPay Voice APK**. If needed, tap **Run workflow**.
5. Wait for the workflow to finish successfully, open the completed run, and download the `NepalPayVoice-debug-apk` artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Tap it to install, allowing installs from that browser/file manager if Android asks.

This is a debug/demo APK. It does not connect to real banks, payment APIs, or a 4G speaker device. Never use demo transactions as proof of payment.
